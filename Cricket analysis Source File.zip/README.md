# T-20 World Cup 2022 Data Analysis
